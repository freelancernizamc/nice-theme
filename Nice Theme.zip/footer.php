<footer class="site-footer clearfix">
			<p>&emsp;&emsp;&emsp;&emsp;&emsp; Copyright &copy; 2022 <a href="https://www.nizam2020.com"> Freelancer Nizam</a> All Right Reserved</p>
			<nav id="footer_nav">
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">About</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
			</nav>
		</footer>
	</div>
</div>
	
	<script src="https://kit.fontawesome.com/000be0daab.js" crossorigin="anonymous"></script>
	<?php wp_footer(); ?>
</body>
</html>